import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ValasztasokComponent } from './valasztasok/valasztasok.component';


const routes: Routes = [{ path: "valasztasok", component: ValasztasokComponent },
{ path: "", redirectTo: "/valasztasok", pathMatch: "full" },
{ path: "**", component: ValasztasokComponent }];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
